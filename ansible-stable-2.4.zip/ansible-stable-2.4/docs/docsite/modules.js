function AnsibleModules($scope) {
  $scope.modules = [];

  $scope.orderProp = "module";
}